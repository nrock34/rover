# @nrock/umami-svelte

A headless **library for existing Svelte 5 applications**. It adds Umami events,
SPA pageviews, form funnels, engagement timing, and live presence. It does not
create an application, start a server, install routes, or supply a dashboard.
The `demo/` directory is a development verification fixture and is not published.

## Install

Until published, build and install the package tarball:

```sh
npm ci
npm run verify
npm pack
# In your existing Svelte application:
npm install /path/to/nrock-umami-svelte-0.1.2.tgz
```

The browser entry has only Svelte as a peer dependency. Server helpers are a
separate `@nrock/umami-svelte/server` export and do not enter browser bundles.

## Add one provider

In an existing SvelteKit root layout:

```svelte
<script>
  import { page } from '$app/state';
  import { AnalyticsProvider } from '@nrock/umami-svelte';
  let { children, data } = $props();
</script>

<AnalyticsProvider
  config={data.analytics.config}
  identity={data.analytics.identity}
  page={{ path: page.url.pathname, title: 'My application' }}
>
  {@render children()}
</AnalyticsProvider>
```

The host supplies public configuration and a pseudonymous identity from its
server load. Example config:

```js
{
  enabled: true,
  scriptUrl: 'https://stats.example.com/script.js',
  // hostUrl optionally overrides the collector base (for reverse proxies).
  websiteId: 'your-umami-website-uuid',
  performance: true,
  presenceUrl: '/api/analytics/presence',
  heartbeatMs: 15000,
  idleMs: 120000,
  engagementMs: 60000
}
```

Identity shape:

```js
{
  id: 'pseudonymous_id_at_least_8_chars',
  auth_state: 'authenticated', // or anonymous
  roles: ['member', 'onboarded-member'],
  onboarding_status: 'completed' // unknown, pending, completed
}
```

Supply a pseudonymous ID for guests too. Reuse it across tabs, and replace it
on login and logout. Derive roles from a verified server session. Never send
email addresses, access tokens, or raw personal data as identifiers.

`enabled` defaults to false. Disabled mode adds no listeners, storage, scripts,
or network requests. Do Not Track and Global Privacy Control are respected by
default. `respectDoNotTrack: false` is an explicit host choice. The library does
not itself persist visitor identifiers or decide a site's consent policy.

### Performance (Umami 3.4+)

`performance: true` opts into LCP, INP, CLS, FCP and TTFB. The library owns its
PerformanceObservers and sends Umami's native `type: 'performance'` packets to
the collector, so measurements appear in its Performance report. Keep a single
provider and do not add another Umami script. Automatic tracking remains off;
the provider records exactly one pageview per route.

Samples flush on route changes, identity changes, page hide and when a tab becomes
hidden. Visit another route or switch tabs before checking the report. There is
no early timeout that would miss interactions later in a visit. FCP, LCP and
TTFB describe the initial document load; SPA transitions do not invent new load
timings. CLS and INP describe the current collection window. INP requires a
qualifying interaction; unsupported or unobserved metrics remain absent. CLS
is zero when layout shifts are supported but none occurred.

Opt-out and unmount disconnect every observer and discard the pending window.
Re-enabling starts fresh and does not replay document timings collected before
opt-out. DNT, GPC and `localStorage['umami.disabled']` also prevent performance
requests. No DOM text, input values, raw query strings or hashes are collected.

## Attach attributes

Existing components only need to forward these attributes to their DOM element:

```svelte
<a href="/signup" data-analytics-event="signup_clicked" data-analytics-location="navigation">
  Sign up
</a>

<form data-analytics-form="newsletter" method="POST">
  <label for="email">Email address</label>
  <input id="email" name="email" type="email" />
  <button>Subscribe</button>
</form>
```

The form emits `newsletter_started` once on actual input and
`newsletter_submitted` on submission. It never reads or sends field values.
Password and hidden inputs are excluded. A reset permits another start event.
**A submit event is not a successful subscription.** Record `newsletter_completed`
in the host's server action after its provider confirms success.

## Content presence: action or wrapper

An action adds no wrapper markup:

```svelte
<script>
  import { getAnalyticsActions } from '@nrock/umami-svelte';
  const { presence } = getAnalyticsActions();
  let { postcard } = $props();
</script>

<article use:presence={{ type: 'postcard', id: postcard.id }}>
  <!-- Your existing content -->
</article>
```

Or use the optional wrapper:

```svelte
<TrackedContent content={{ type: 'program', id: program.id }}>
  <ProgramDetail {program} />
</TrackedContent>
```

For centralized route classification, pass `content` in the provider's `page`
prop instead. **Use one method for the primary content on a page.** A provider
represents one browser page at a time; it is not impression tracking for a feed
of cards. Multiple live tabs are supported and deduplicated by visitor ID.

The other bound actions are `event` and `form`. For application events call
`getAnalytics().track('event_name', { property: 'value' })`. Call the context
helpers during component initialization. Use `createAnalytics()` and
`createActions(client)` outside Svelte context or for imperative integrations.

## Add a handler to your existing backend

The library deliberately does not listen on a port. Import helpers in an
existing SvelteKit endpoint, Strapi controller, Express handler, or other server:

```ts
import { createPresence, createRedisPresenceStore } from '@nrock/umami-svelte/server';

// Use your application's ioredis connection. No Redis dependency is bundled.
const presence = createPresence({
  store: createRedisPresenceStore(redis, { prefix: 'my-app:{presence}:' }),
  ttlMs: 60000
});

// After the host validates the request and resolves a trusted identity:
await presence.heartbeat(browserPayload, trustedIdentity);

// Behind the host's staff authorization:
const snapshot = await presence.snapshot({ role: 'member', contentType: 'postcard' });
```

The host must enforce same-origin browser POSTs, JSON and request-size limits,
rate limits, and access control for snapshots. Never use browser-supplied roles
or IDs as `trustedIdentity`. For edge deployments without direct Redis access,
proxy to an existing backend with a private server-to-server credential. Keep
that credential out of provider config. The helper validates and allowlists the
browser payload again and never includes visitor IDs in snapshots.

For local development or tests use `createMemoryPresenceStore()`; memory storage
is isolated per process and is unsuitable for multiple production instances.
Redis updates are atomic; sequence numbers reject out-of-order heartbeats and
leave messages. Leave tombstones prevent immediate resurrection by late
requests. TTL expiry handles closed tabs, crashes, or lost connections.

Snapshots provide deduplicated totals, exact role/status filters, per-page
online/active counts, and site-wide view rankings for roughly 15 minutes,
the previous 15 minutes, 1 hour, and 24 hours. Redis view windows use minute
buckets and may lag up to 30 seconds. Historical rankings are **not role-filtered**;
use Umami reports for historical segmentation. Counts per role overlap for
members with multiple roles, so they must not be added together. The default
presence scan cap is 10,000 tabs; a capped response explicitly marks `capped`.
Use an isolated Redis namespace and a single Redis primary (or a cluster hash
tag as in the example). Rollups are temporary; Umami owns historical analytics.

## Confirmed server outcomes

```ts
import { sendServerEvent } from '@nrock/umami-svelte/server';

// Only after the host confirms account creation/subscription:
await sendServerEvent({
  enabled: analyticsEnabled,
  endpoint: 'https://stats.example.com',
  websiteId,
  id: visitorId,
  hostname: requestUrl.hostname,
  path: requestUrl.pathname,
  event: 'signup_completed',
  properties: { source: 'signup_form' },
  userAgent: request.headers.get('user-agent') ?? undefined
});
```

The helper is best-effort, times out, and returns false on failure. It is not a
transactional outbox or an authoritative conversion ledger. Use database totals
for exact business counts. Keep the pre-signup visitor ID on the completion
event if the funnel should connect anonymous clicks to successful registration.
Anonymous and authenticated histories are not automatically retroactively merged.

Umami's session identity also depends on the request IP and user agent. Forward
the original `userAgent` and the adapter's **trusted** client `ip` for production
server events; an ID alone does not connect events arriving from different
network addresses. For Docker-local testing where browser and server requests
share the collector-facing NAT address, omit `ip`: overriding it with the app's
loopback address would split conversion funnels. Verify the funnel in real Umami,
not only the count of individual events. Never trust a browser-supplied IP header.


## Measurement semantics

- **Online:** at least one tab sent a heartbeat within the server TTL, including
  a background tab. Departure detection can lag by that TTL.
- **Active:** at least one visible, focused tab has recent input/scroll, with a
  configurable reading grace (`idleMs`, default two minutes). This is a heuristic
  for engagement, not proof of attention.
- **Engaged time:** visible/focused time within that grace, emitted as delta
  milliseconds in `engagement` events. Idle/background time is excluded, and a
  suspended laptop cannot add a long gap. A long reader without interaction
  eventually becomes idle.
- **Views:** pageviews and `content_view` events are distinct from heartbeat
  requests. Heartbeats never become Umami pageviews.
- **Geography:** Umami derives approximate geography from its collection request.
  A proxy/server event must preserve trusted client network information if its
  geography should match browser events.

Query strings and URL fragments are excluded by default. Only explicit
`queryKeys` enter Umami events; presence always accepts pathname only. Page
titles, content IDs and custom properties are supplied by the host: keep them
free of personal information. One provider should own Umami in a document;
remove any previously installed automatic tracker to avoid duplicate pageviews.

## Verify changes

```sh
npm run verify
TEST_REDIS_URL=redis://127.0.0.1:6379 npm run test:redis
npm run demo
```

Tests cover SSR, lifecycle cleanup, disabled behavior, privacy signals, SPA
navigation, engagement, identity changes, form attributes/actions, TTL expiry,
deduplication, stale messages and real Redis Lua execution. The fixture uses
synthetic identities and a fake Umami collector; production integration should
also be smoke-tested against the deployed Umami version.
